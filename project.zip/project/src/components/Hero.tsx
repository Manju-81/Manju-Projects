import React from 'react';
import { ArrowRight } from 'lucide-react';

export default function Hero() {
  return (
    <section className="pt-32 pb-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center">
          <h1 className="text-5xl md:text-6xl font-bold text-slate-900 mb-6">
            The Future of Voice
            <span className="text-indigo-600"> Interaction</span>
          </h1>
          <p className="text-xl text-slate-600 mb-8 max-w-2xl mx-auto">
            Transform your digital experience with Voxia's advanced virtual voice assistant. 
            Powered by cutting-edge AI for natural, intuitive interactions.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <button className="bg-indigo-600 text-white px-8 py-3 rounded-lg hover:bg-indigo-700 flex items-center justify-center">
              Try Voice Demo <ArrowRight className="ml-2 h-5 w-5" />
            </button>
            <button className="border border-slate-200 text-slate-600 px-8 py-3 rounded-lg hover:bg-slate-50">
              View Documentation
            </button>
          </div>
        </div>
        <div className="mt-16 relative">
          <div className="aspect-video rounded-xl overflow-hidden shadow-2xl">
            <img 
              src="https://images.unsplash.com/photo-1520333789090-1afc82db536a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2071&q=80"
              alt="Voice assistant interface"
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      </div>
    </section>
  );
}