import React from 'react';

const posts = [
  {
    title: 'The Future of Voice AI',
    excerpt: 'Exploring upcoming trends in voice assistant technology and their impact on various industries.',
    image: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2072&q=80',
    date: 'Mar 15, 2024'
  },
  {
    title: 'Voice Commerce Revolution',
    excerpt: 'How voice assistants are transforming the e-commerce landscape and shopping experiences.',
    image: 'https://images.unsplash.com/photo-1554774853-aae0a22c8aa4?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80',
    date: 'Mar 10, 2024'
  },
  {
    title: 'Voice AI Security',
    excerpt: 'Best practices for implementing secure voice authentication and data protection.',
    image: 'https://images.unsplash.com/photo-1639322537228-f710d846310a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2072&q=80',
    date: 'Mar 5, 2024'
  }
];

export default function Blog() {
  return (
    <section id="blog" className="py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold text-slate-900 mb-4">
            Latest Insights
          </h2>
          <p className="text-lg text-slate-600 max-w-2xl mx-auto">
            Stay updated with the latest trends and developments in voice technology.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {posts.map((post, index) => (
            <article 
              key={index}
              className="bg-white rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="aspect-video">
                <img 
                  src={post.image}
                  alt={post.title}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="p-6">
                <p className="text-sm text-slate-500 mb-2">{post.date}</p>
                <h3 className="text-xl font-semibold text-slate-900 mb-2">
                  {post.title}
                </h3>
                <p className="text-slate-600 mb-4">
                  {post.excerpt}
                </p>
                <a href="#" className="text-indigo-600 font-medium">
                  Read more →
                </a>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}