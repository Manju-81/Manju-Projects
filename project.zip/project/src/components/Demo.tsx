import React, { useState } from 'react';
import { Mic } from 'lucide-react';

export default function Demo() {
  const [isListening, setIsListening] = useState(false);
  const [response, setResponse] = useState('');

  const handleVoiceCommand = () => {
    setIsListening(true);
    // Simulated response after 1 second
    setTimeout(() => {
      setIsListening(false);
      setResponse('I heard your command! (This is a demo response)');
    }, 1000);
  };

  return (
    <section id="demo" className="py-20 bg-slate-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold mb-4">
            Try Voxia Assistant
          </h2>
          <p className="text-lg text-slate-300 max-w-2xl mx-auto">
            Experience the power of voice interaction firsthand with our interactive demo.
          </p>
        </div>

        <div className="max-w-2xl mx-auto">
          <div className="bg-slate-800 rounded-xl p-8">
            <div className="text-center mb-8">
              <p className="text-slate-300 mb-4">Try saying:</p>
              <div className="flex flex-wrap justify-center gap-2">
                <span className="bg-slate-700 px-3 py-1 rounded-full text-sm">
                  "Open Google"
                </span>
                <span className="bg-slate-700 px-3 py-1 rounded-full text-sm">
                  "Play music"
                </span>
                <span className="bg-slate-700 px-3 py-1 rounded-full text-sm">
                  "Tell me a joke"
                </span>
                <span className="bg-slate-700 px-3 py-1 rounded-full text-sm">
                  "Weather forecast"
                </span>
              </div>
            </div>

            <div className="flex flex-col items-center">
              <button
                onClick={handleVoiceCommand}
                className={`p-6 rounded-full ${
                  isListening 
                    ? 'bg-red-500 animate-pulse' 
                    : 'bg-indigo-600 hover:bg-indigo-700'
                }`}
              >
                <Mic className="h-8 w-8" />
              </button>
              <p className="mt-4 text-slate-300">
                {isListening ? 'Listening...' : 'Click to speak'}
              </p>
              {response && (
                <div className="mt-8 p-4 bg-slate-700 rounded-lg w-full">
                  <p className="text-slate-200">{response}</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}