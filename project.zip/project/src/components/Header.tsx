import React, { useState } from 'react';
import { Mic, Menu, X } from 'lucide-react';

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="fixed w-full bg-white/80 backdrop-blur-md z-50 border-b border-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <Mic className="h-8 w-8 text-indigo-600" />
            <span className="ml-2 text-2xl font-bold text-slate-900">Voxia</span>
          </div>
          
          <nav className="hidden md:flex space-x-8">
            <a href="#features" className="text-slate-600 hover:text-indigo-600">Features</a>
            <a href="#solutions" className="text-slate-600 hover:text-indigo-600">Solutions</a>
            <a href="#demo" className="text-slate-600 hover:text-indigo-600">Demo</a>
            <a href="#resources" className="text-slate-600 hover:text-indigo-600">Resources</a>
            <a href="#blog" className="text-slate-600 hover:text-indigo-600">Blog</a>
          </nav>

          <button className="hidden md:block bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700">
            Try Demo
          </button>

          <button 
            className="md:hidden"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X /> : <Menu />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      {isMenuOpen && (
        <div className="md:hidden">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            <a href="#features" className="block px-3 py-2 text-slate-600">Features</a>
            <a href="#solutions" className="block px-3 py-2 text-slate-600">Solutions</a>
            <a href="#demo" className="block px-3 py-2 text-slate-600">Demo</a>
            <a href="#resources" className="block px-3 py-2 text-slate-600">Resources</a>
            <a href="#blog" className="block px-3 py-2 text-slate-600">Blog</a>
            <button className="w-full text-left px-3 py-2 bg-indigo-600 text-white rounded-lg">
              Try Demo
            </button>
          </div>
        </div>
      )}
    </header>
  );
}