import React from 'react';
import { Mic, Globe, Music, SmilePlus, Cloud, Code, BookOpen, ArrowRight, MessageSquare, Building2, Brain, Shield } from 'lucide-react';
import Header from './components/Header';
import Hero from './components/Hero';
import Features from './components/Features';
import Solutions from './components/Solutions';
import Demo from './components/Demo';
import Resources from './components/Resources';
import Blog from './components/Blog';
import Footer from './components/Footer';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white">
      <Header />
      <main>
        <Hero />
        <Features />
        <Solutions />
        <Demo />
        <Resources />
        <Blog />
      </main>
      <Footer />
    </div>
  );
}

export default App;