// Handle form submission
document.getElementById('uploadForm').addEventListener('submit', async (event) => {
    event.preventDefault(); // Prevent the default form submission

    const formData = new FormData(event.target);

    try {
        const response = await fetch('/upload-document', { // Replace with your actual API endpoint
            method: 'POST',
            body: formData
        });

        const result = await response.text();
        alert("Uploaded Document Successfully");
    } catch (error) {
        alert("An error occurred while uploading the document.");
        console.error(error);
    }
});

// Redirect to payment page
function redirectToPayment(event) {
    event.preventDefault(); // Prevent default button behavior

    // Validate required fields
    const recipientEmail = document.getElementById('recipientEmail').value.trim();
    const deliveryDate = document.getElementById('deliveryDate').value.trim();
    const category = document.getElementById('category').value;
    const documentFile = document.getElementById('document').files.length;

    // Check if all required fields are filled
    if (!recipientEmail) {
        alert("Please enter the recipient's email.");
        return;
    }

    if (!deliveryDate) {
        alert("Please select a delivery date.");
        return;
    }

    if (!category) {
        alert("Please select a document type.");
        return;
    }

    if (documentFile === 0) {
        alert("Please upload a document.");
        return;
    }
    alert("To send the capsule, please proceed to the payment page.");

    // Redirect to payment page if all fields are valid
    window.location.href = 'pay.html'; // Replace with actual payment page URL
}

// Attach event listener to "Send Capsule" button
document.getElementById('sendCapsuleButton').addEventListener('click', redirectToPayment);
