// Toggle between video upload and recording fields
function toggleVideoInput() {
    const videoType = document.getElementById('videoType').value;
    const uploadField = document.getElementById('uploadVideoField');
    const recordField = document.getElementById('recordVideoField');

    if (videoType === 'upload') {
        uploadField.style.display = 'block';
        recordField.style.display = 'none';
    } else if (videoType === 'record') {
        uploadField.style.display = 'none';
        recordField.style.display = 'block';
        initializeCamera();
    } else {
        uploadField.style.display = 'none';
        recordField.style.display = 'none';
    }
}

let mediaRecorder;
let recordedChunks = [];

// Initialize camera for recording
async function initializeCamera() {
    const stream = await navigator.mediaDevices.getUserMedia({ video: true });
    document.getElementById('preview').srcObject = stream;
    mediaRecorder = new MediaRecorder(stream);

    mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
            recordedChunks.push(event.data);
        }
    };
}

// Start recording
function startRecording() {
    recordedChunks = [];
    mediaRecorder.start();
    alert("Recording started!");
}

// Stop recording and save the recorded video blob
function stopRecording() {
    mediaRecorder.stop();
    mediaRecorder.onstop = () => {
        const blob = new Blob(recordedChunks, { type: 'video/webm' });
        const videoFile = new File([blob], 'recording.webm', { type: 'video/webm' });
        const formData = new FormData();
        formData.append('videoFile', videoFile);
        alert("Recording stopped and video saved.");
    };
}

// Handle form submission
document.getElementById('videoForm').addEventListener('submit', async (event) => {
    event.preventDefault();

    const formData = new FormData(event.target);

    try {
        const response = await fetch('/send-video', {
            method: 'POST',
            body: formData
        });

        const result = await response.text();
        alert("Uploaded Video Successfully");
    } catch (error) {
        alert("An error occurred while sending the video.");
        console.error(error);
    }
});

// Redirect to payment page
function redirectToPayment() {
    const recipientEmail = document.getElementById('recipientEmail').value.trim();
    const deliveryDate = document.getElementById('deliveryDate').value.trim();
    const videoType = document.getElementById('videoType').value;

    if (!recipientEmail || !deliveryDate || !videoType) {
        alert("Please fill out all required fields.");
        return;
    }
    alert("To send the capsule, please proceed to the payment page.");

    window.location.href = 'pay.html'; // Replace with the actual payment page URL
}
