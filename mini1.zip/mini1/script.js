
const logo = document.getElementById('logo');

logo.addEventListener('click', () => {
    // Toggle the enlargement
    if (logo.style.transform === 'scale(1.5)') {
        logo.style.transform = 'scale(1)';
    } else {
        logo.style.transform = 'scale(1.5)'; // Enlarge to 150%
    }
});
