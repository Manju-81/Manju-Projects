// Show selected tab and hide others
function showTab(tabName) {
    // Hide all tab contents
    const tabs = document.querySelectorAll('.tab-content');
    tabs.forEach(tab => {
        tab.style.display = 'none';
    });

    // Hide all image sections
    const images = document.querySelectorAll('.image-section');
    images.forEach(image => {
        image.style.display = 'none';
    });

    // Show the selected tab content
    const selectedTabContent = document.getElementById(tabName);
    if (selectedTabContent) {
        selectedTabContent.style.display = 'block';
    }

    // Show the associated images
    const associatedImages = document.getElementById(`${tabName}-images`);
    if (associatedImages) {
        associatedImages.style.display = 'flex';
    }
}

// Ensure no tab content is displayed initially
window.onload = function() {
    const tabs = document.querySelectorAll('.tab-content');
    tabs.forEach(tab => {
        tab.style.display = 'none';
    });

    const images = document.querySelectorAll('.image-section');
    images.forEach(image => {
        image.style.display = 'none';
    });
};