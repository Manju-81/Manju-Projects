const wrapper = document.getElementById('container');
const registerLink = document.querySelector('.register-link');
const loginLink = document.querySelector('.login-link');

// Switching between Login and Register views
registerLink.onclick = () => {
  wrapper.classList.add('active');
}

loginLink.onclick = () => {
  wrapper.classList.remove('active');
}

// Sign-up button functionality
document.getElementById('signUpButton').addEventListener('click', function() {
  const name = document.getElementById('signUpName').value;
  const email = document.getElementById('signUpEmail').value;
  const password = document.getElementById('signUpPassword').value;

  if (name && email && password) {
    localStorage.setItem('name', name);
    localStorage.setItem('email', email);
    localStorage.setItem('password', password);
    alert('Sign up successful! You can now sign in.');
    document.getElementById('signUpForm').reset();
  } else {
    alert('Please fill in all fields.');
  }
});

// Sign-in button functionality
document.getElementById('signInButton').addEventListener('click', function() {
  const email = document.getElementById('signInEmail').value;
  const password = document.getElementById('signInPassword').value;
  const storedEmail = localStorage.getItem('email');
  const storedPassword = localStorage.getItem('password');

  if (email === storedEmail && password === storedPassword) {
    alert('Sign in successful! Redirecting...');
    window.location.href = "main.html";
  } else {
    alert('Email or password is incorrect. Please try again.');
  }
});
