document.getElementById('pay-btn').addEventListener('click', function() {
    document.querySelector('.payment-methods').style.display = 'block';
  });
  
  document.getElementById('credit-debit-card').addEventListener('click', function() {
    // Integrate credit/debit card payment gateway here
    alert('Credit/Debit Card selected');
  });
  
  document.getElementById('net-banking').addEventListener('click', function() {
    // Integrate net banking payment gateway here
    alert('Net Banking selected');
  });
  
  document.getElementById('upi').addEventListener('click', function() {
    // Integrate UPI payment gateway here
    alert('UPI selected');
  });
  
  document.getElementById('wallets').addEventListener('click', function() {
    // Integrate wallets payment gateway here
    alert('Wallets selected');
  });
  
  
  document.getElementById('credit-debit-card').addEventListener('click', function() {
    document.getElementById('credit-debit-card-form').style.display = 'block';
    document.getElementById('net-banking-form').style.display = 'none';
    document.getElementById('upi-form').style.display = 'none';
    document.getElementById('wallets-form').style.display = 'none';
  });
  
  
  document.getElementById('net-banking').addEventListener('click', function() {
      document.getElementById('net-banking-form').style.display = 'block';
      document.getElementById('credit-debit-card-form').style.display = 'none';
      document.getElementById('upi-form').style.display = 'none';
      document.getElementById('wallets-form').style.display = 'none';
  });
  
  document.getElementById('upi').addEventListener('click', function() {
      document.getElementById('upi-form').style.display = 'block';
      document.getElementById('credit-debit-card-form').style.display = 'none';
      document.getElementById('net-banking-form').style.display = 'none';
      document.getElementById('wallets-form').style.display = 'none';
  });
  
  document.getElementById('wallets').addEventListener('click', function() {
      document.getElementById('wallets-form').style.display = 'block';
      document.getElementById('credit-debit-card-form').style.display = 'none';
      document.getElementById('net-banking-form').style.display = 'none';
      document.getElementById('upi-form').style.display = 'none';
  });
  // Wait for the DOM to fully load before adding event listeners
  document.addEventListener('DOMContentLoaded', (event) => {
    const payButton = document.getElementById('pay');
    const requiredFields = document.querySelectorAll('.required-field'); // Assuming required fields have this class
  
    // Event listener for Pay button click
    payButton.addEventListener('click', function(event) {
      event.preventDefault(); // Prevent default form submission
  
      let allFilled = true;
  
      requiredFields.forEach((field) => {
        if (field.value.trim() === '') {
          allFilled = false;
          field.focus(); // Focus on the first empty field
          return; // Exit loop once an empty field is found
        }
      });
  
      if (!allFilled) {
        alert("Please fill in all required fields before proceeding with the payment.");

      } else {
        alert("You have clicked the 'Pay Now' button! Transaction completed successfully.");

      }
      const cardNumber = document.getElementById('card-number').value; // Card Number input
      const expirationDate = document.getElementById('expiration-date').value; // Expiration Date input
      const cvv = document.getElementById('cvv').value; // CVV input
  
      // Confirmation prompt for payment
      const paymentConfirmation = confirm(
        `To send a capsule to the future, a payment is required. Do you wish to proceed?\n\nCard Number: ${cardNumber}\nExpiration Date: ${expirationDate}\nCVV: ${cvv}`
      );
  
      if (paymentConfirmation) {
        alert(`Processing payment with:\nCard Number: ${cardNumber}\nExpiration Date: ${expirationDate}`);
        window.location.href = 'pay.html'; // Redirect to payment page
      } else {
        alert('Your payment has not been processed. Payment is required to proceed.');
      }
    });
  });
  function validateForm() {
      const accountNumber = document.getElementById("accountNumber").value;
      const ifscCode = document.getElementById("ifscCode").value;
      const password = document.getElementById("password").value;

      if (accountNumber.length < 10 || accountNumber.length > 12) {
          alert("Account number must be between 10 and 12 digits.");
          return false;
      }

      const ifscPattern = /^[A-Za-z]{4}\d{7}$/;
      if (!ifscPattern.test(ifscCode)) {
          alert("Please enter a valid IFSC code.");
          return false;
      }

      if (password.length < 6) {
          alert("Password should be at least 6 characters.");
          return false;
      }

      alert("Login successful!");
      return true;
  }
  function validateForm1() {
    const upiID = document.getElementById("upiID").value;
    const mobileNumber = document.getElementById("mobileNumber").value;
    const pin = document.getElementById("pin").value;

    // Check if UPI ID contains an "@" symbol
    if (!upiID.includes("@")) {
        alert("Please enter a valid UPI ID with '@'.");
        return false;
    }

    // Mobile number validation for 10 digits
    if (mobileNumber.length !== 10 || isNaN(mobileNumber)) {
        alert("Mobile number must be a 10-digit number.");
        return false;
    }

    // UPI PIN should be at least 4 digits
    if (pin.length < 4 || isNaN(pin)) {
        alert("UPI PIN should be at least 4 digits.");
        return false;
    }

    alert("Login successful!");
    return true;
}

function validateForm2() {
  const walletID = document.getElementById("walletID").value;
  const mobileNumber = document.getElementById("mobileNumber").value;
  const password = document.getElementById("password").value;

  // Wallet ID validation
  if (walletID.length < 6) {
      alert("Wallet ID must be at least 6 characters long.");
      return false;
  }

  // Mobile number validation for 10 digits
  if (mobileNumber.length !== 10 || isNaN(mobileNumber)) {
      alert("Mobile number must be a 10-digit number.");
      return false;
  }

  // Password should be at least 6 characters
  if (password.length < 6) {
      alert("Password should be at least 6 characters.");
      return false;
  }

  alert("Login successful!");
  alert(`Processing payment`);

  return true;
}
