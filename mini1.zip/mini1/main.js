// JavaScript to handle interactivity on the page

// Select elements
const createCapsuleButton = document.querySelector('.create-btn'); // Button to create capsule
const optionsSection = document.getElementById('options-section'); // Options section to show
const recordingStatus = document.getElementById('recording-status');
const recordedVideo = document.getElementById('recorded-video');
const startRecordingButton = document.getElementById('start-recording');
const stopRecordingButton = document.getElementById('stop-recording');

// Show the options section when "Create Capsule" button is clicked
createCapsuleButton.addEventListener('click', () => {
  optionsSection.style.display = optionsSection.style.display === 'none' ? 'block' : 'none';
});

// Recording status handling
let isRecording = false;

function updateRecordingStatus() {
  recordingStatus.textContent = isRecording ? "Recording in progress..." : "Not recording";
  recordingStatus.style.color = isRecording ? "#d9534f" : "#333";
}

// Start recording functionality
startRecordingButton.addEventListener('click', () => {
  isRecording = true;
  updateRecordingStatus();
  // Add any code to start recording here, such as accessing the media devices API.
});

// Stop recording functionality
stopRecordingButton.addEventListener('click', () => {
  isRecording = false;
  updateRecordingStatus();
  // Add any code to stop recording here, save or preview video if applicable.
  recordedVideo.style.display = 'block';  // Show recorded video after recording ends
});

// Function to initialize the page
function init() {
  // Set initial recording status
  updateRecordingStatus();
  // Hide recorded video element initially
  recordedVideo.style.display = 'none';
}

// Initialize page on load
window.onload = init;
