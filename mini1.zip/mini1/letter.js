// Toggle between letter composition and file upload fields
function toggleLetterInput() {
    const letterType = document.getElementById('letterType').value;
    const composeField = document.getElementById('composeLetterField');
    const uploadField = document.getElementById('uploadLetterField');

    // Display the corresponding field based on the selected option
    if (letterType === 'compose') {
        composeField.style.display = 'block';
        uploadField.style.display = 'none';
    } else if (letterType === 'upload') {
        composeField.style.display = 'none';
        uploadField.style.display = 'block';
    } else {
        composeField.style.display = 'none';
        uploadField.style.display = 'none';
    }
}

// Handle form submission
document.getElementById('letterForm').addEventListener('submit', async (event) => {
    event.preventDefault(); // Prevent traditional form submission

    const formData = new FormData(event.target);

    try {
        const response = await fetch('/upload-letter', { // Replace with your actual endpoint
            method: 'POST',
            body: formData
        });

        const result = await response.text();
        alert("Letter uploaded successfully!");
    } catch (error) {
        alert("An error occurred while uploading the letter.");
        console.error(error);
    }
});

// Redirect to payment page with a warning
function redirectToPayment(event) {
    event.preventDefault(); // Prevent default button behavior

    // Validate required fields
    const recipientEmail = document.getElementById('recipientEmail').value.trim();
    const deliveryDate = document.getElementById('deliveryDate').value.trim();
    const letterType = document.getElementById('letterType').value;

    // Check if all required fields are filled
    if (!recipientEmail) {
        alert("Please enter the recipient's email.");
        return;
    }

    if (!deliveryDate) {
        alert("Please select a delivery date.");
        return;
    }

    if (!letterType) {
        alert("Please select a letter type (compose or upload).");
        return;
    }

    // Check if the chosen letter type field is filled
    if (letterType === 'compose' && !document.getElementById('letterContent').value.trim()) {
        alert("Please write your letter content.");
        return;
    }

    if (letterType === 'upload' && document.getElementById('letterFile').files.length === 0) {
        alert("Please upload your letter file.");
        return;
    }

    // Show an alert about payment before redirecting
    alert("To send the capsule, please proceed to the payment page.");

    // Redirect to payment page
    window.location.href = 'pay.html'; // Replace with the actual payment page URL
}

// Attach event listener to "Send Capsule" button
document.getElementById('sendCapsuleButton').addEventListener('click', redirectToPayment);
